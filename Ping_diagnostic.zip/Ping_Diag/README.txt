Example inputs:

"192.168.1.1"                  # IPv4
"2001:4860:4860::8888"         # IPv6
"google.com"                   # Domain name


discord: https://discord.gg/zsGTqgnsmK
website: thezperformance.de